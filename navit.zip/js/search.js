$(window).on('load',function(){
		$("#task-list>li").css({
			'display':'none',
		});
		$("#task-list>li>a").css({
			'color':'#848124',
			'font-weight':'bold',
			'text-decoration':'none'
		});
		$('#txtSearch').on('keyup change',function(){
			$("#task-list>li").css({
				'display':'none',
			});
		var search = $(this).val();
        if (jQuery.trim(search) != '') {
            var low = search.toLowerCase();
            var high = search.toUpperCase();
			var b = search.split('');
			b[0] = b[0].toUpperCase();
			var sent = b.join('');
            $("#task-list>li:contains('"+ low +"')").css('display','block');
            $("#task-list>li:contains('"+ high +"')").css('display','block');
            $("#task-list>li:contains('"+ search +"')").css('display','block');
            $("#task-list>li:contains('"+ sent +"')").css('display','block');
        } else {
            $('#task-list li').hide();
        }
	});
});