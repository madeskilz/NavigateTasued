﻿function initialize(x) {
    //Define marker icons
    var icton = 'img/markers/admin_small.png';
    var blocks = 'img/markers/house.png';
    var sbkon = 'img/markers/star.png';
    var buildings = 'img/markers/assets_small.png';
    var marker = 'img/markers/marker.png';
    var ltcon = 'img/markers/book.png';
    var fieldon = 'img/markers/medal_gold_1.png';
    var lib = 'img/markers/gl_small.png';
    var elearn = 'img/markers/monitor.png';
    var pin = 'img/markers/pin.png';
    var clinicon = 'img/markers/add.png';


    //Building LatLng
    var vcbuildingP = new google.maps.LatLng(6.784308, 3.927735);
    var ogdP = new google.maps.LatLng(6.785381, 3.929760);
    var libraryP = new google.maps.LatLng(6.785048, 3.930760);
    var ppsP = new google.maps.LatLng(6.786310, 3.930818);
    var ictP = new google.maps.LatLng(6.783944, 3.931726);
    var sbkP = new google.maps.LatLng(6.786841, 3.928881);
    var cepepP = new google.maps.LatLng(6.786198, 3.929170);
    var auditoriumP = new google.maps.LatLng(6.785425, 3.928870);
    var elearningP = new google.maps.LatLng(6.784419, 3.929304);
    var adofficeP = new google.maps.LatLng(6.783136, 3.928525);
    var ltP = new google.maps.LatLng(6.783225, 3.929783);
    var etfcoaevotP = new google.maps.LatLng(6.782484, 3.929428);
    var kaafP = new google.maps.LatLng(6.781742, 3.930599);
    var coaevotP = new google.maps.LatLng(6.781820, 3.929508);
    var cosmasP = new google.maps.LatLng(6.780712, 3.928338);
    var clinicP = new google.maps.LatLng(6.781545, 3.926448);
    var fieldP = new google.maps.LatLng(6.781800, 3.924914);

    //Default settings
    var mapProp = {
        center: new google.maps.LatLng(6.783447, 3.928291),
        zoom: 17,
        mapTypeId: google.maps.MapTypeId.HYBRID,
        zoomControl: true,
        mapTypeControl: false,
        scaleControl: false,
        streetViewControl: false,
        rotateControl: false,
        fullscreenControl: true
    };
    var infoWindow = new google.maps.InfoWindow({ map: map });

    // Try HTML5 geolocation.
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            var pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            var marker = new google.maps.Marker({
                position: pos,
                map: map,
                title: 'Present Location',
                visible: true
            });
            marker.setMap(map);
            infoWindow.setPosition(pos);
            infoWindow.setContent('Location found');
            map.setCenter(pos);
        }, function () {
            handleLocationError(true, infoWindow, map.getCenter());
        });
    } else {
        // Browser doesn't support Geolocation
        handleLocationError(false, infoWindow, map.getCenter());
    }

    //create map
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);

    //change map type
    $('.mapType').on('click', function () {
        var self = $(this);
        var nextTypeID = this.text;
        if (nextTypeID = "HYBRID MAP(current)") {
            map.setMapTypeId(google.maps.MapTypeId.HYBRID);
        } else {
            map.setMapTypeId(google.maps.MapTypeId.ROADMAP);
        }
        $('.mapType').removeClass('act');
        self.addClass('act');
    });

    //add markers to the map
    var ogdwindow = new google.maps.InfoWindow({
        content: 'Otunba Gbenga Daniel Hall'
    });

    var ogd = new google.maps.Marker({
        position: ogdP,
        map: map,
        title: "OGD HALL",
        icon: buildings
    });

    google.maps.event.addListener(ogd, 'click', function () {
        ogdwindow.open(map, ogd);
    });

    ogd.setMap(map);

    var librarywindow = new google.maps.InfoWindow({
        content: 'TASUED Library'
    });

    var library = new google.maps.Marker({
        position: libraryP,
        map: map,
        title: "TASUED Library",
        icon: lib
    });

    google.maps.event.addListener(library, 'click', function () {
        librarywindow.open(map, library);
    });

    library.setMap(map);

    var ppswindow = new google.maps.InfoWindow({
        content: 'Pet Chem Complex'
    });

    var pps = new google.maps.Marker({
        position: ppsP,
        map: map,
        title: 'ALex O. Science Complex',
        icon: buildings
    });

    google.maps.event.addListener(pps, 'click', function () {
        ppswindow.open(map, pps);
    });

    pps.setMap(map);

    var ictwindow = new google.maps.InfoWindow({
        content: 'Information and Communication Technology'
    });

    var ict = new google.maps.Marker({
        position: ictP,
        map: map,
        title: "ICT!",
        icon: icton
    });

    google.maps.event.addListener(ict, 'click', function () {
        ictwindow.open(map, ict);
    });

    ict.setMap(map);

    var sbkwindow = new google.maps.InfoWindow({
        content: 'Science Complex'
    });

    var sbk = new google.maps.Marker({
        position: sbkP,
        map: map,
        title: "SBK Building!",
        icon: sbkon
    });

    google.maps.event.addListener(sbk, 'click', function () {
        sbkwindow.open(map, sbk);
    });

    sbk.setMap(map);

    var cepepwindow = new google.maps.InfoWindow({
        content: 'CEPEP Building'
    });

    var cepep = new google.maps.Marker({
        position: cepepP,
        map: map,
        title: "CEPEP Building!",
        icon: buildings
    });

    google.maps.event.addListener(cepep, 'click', function () {
        cepepwindow.open(map, cepep);
    });

    cepep.setMap(map);

    var auditoriumwindow = new google.maps.InfoWindow({
        content: 'The College Auditorium'
    });

    var auditorium = new google.maps.Marker({
        position: auditoriumP,
        map: map,
        title: "The College Auditorium!",
        icon: ltcon
    });

    google.maps.event.addListener(auditorium, 'click', function () {
        auditoriumwindow.open(map, auditorium);
    });

    auditorium.setMap(map);

    var elearningwindow = new google.maps.InfoWindow({
        content: 'E-Learning Building'
    });

    var elearning = new google.maps.Marker({
        position: elearningP,
        map: map,
        title: "The University Block",
        icon: elearn
    });

    google.maps.event.addListener(elearning, 'click', function () {
        elearningwindow.open(map, elearning);
    });

    elearning.setMap(map);

    var vcbuildingwindow = new google.maps.InfoWindow({
        content: "Vice Chancellor's Office"
    });

    var vcbuilding = new google.maps.Marker({
        position: vcbuildingP,
        map: map,
        title: "Vice Chancellor's Office!",
        icon: lib
    });

    google.maps.event.addListener(vcbuilding, 'click', function () {
        vcbuildingwindow.open(map, vcbuilding);
    });

    vcbuilding.setMap(map);

    var adofficewindow = new google.maps.InfoWindow({
        content: 'Admission Office (Block F)'
    });

    var adoffice = new google.maps.Marker({
        position: adofficeP,
        map: map,
        title: "Admission Office (Block F)!",
        icon: blocks
    });

    google.maps.event.addListener(adoffice, 'click', function () {
        adofficewindow.open(map, adoffice);
    });

    adoffice.setMap(map);

    var ltwindow = new google.maps.InfoWindow({
        content: 'Lecture Theatre'
    });

    var lt = new google.maps.Marker({
        position: ltP,
        map: map,
        title: "Lecture Theatre!",
        icon: ltcon
    });

    google.maps.event.addListener(lt, 'click', function () {
        ltwindow.open(map, lt);
    });

    lt.setMap(map);

    var etfcoaevotwindow = new google.maps.InfoWindow({
        content: 'ETF'
    });

    var etfcoaevot = new google.maps.Marker({
        position: etfcoaevotP,
        map: map,
        title: "ETF!",
        icon: ltcon
    });

    google.maps.event.addListener(etfcoaevot, 'click', function () {
        etfcoaevotwindow.open(map, etfcoaevot);
    });

    etfcoaevot.setMap(map);

    var kaafwindow = new google.maps.InfoWindow({
        content: 'Keshington Building (KAAF)'
    });

    var kaaf = new google.maps.Marker({
        position: kaafP,
        map: map,
        title: "Keshington Building!",
        icon: buildings
    });

    google.maps.event.addListener(kaaf, 'click', function () {
        kaafwindow.open(map, kaaf);
    });

    kaaf.setMap(map);

    var coaevotwindow = new google.maps.InfoWindow({
        content: 'COAEVOT Building'
    });

    var coaevot = new google.maps.Marker({
        position: coaevotP,
        map: map,
        title: "COAEVOT Building",
        icon: buildings
    });

    google.maps.event.addListener(coaevot, 'click', function () {
        coaevotwindow.open(map, coaevot);
    });

    coaevot.setMap(map);

    var cosmaswindow = new google.maps.InfoWindow({
        content: 'COSMAS Building'
    });

    var cosmas = new google.maps.Marker({
        position: cosmasP,
        map: map,
        title: "COSMAS Building",
        icon: buildings
    });

    google.maps.event.addListener(cosmas, 'click', function () {
        cosmaswindow.open(map, cosmas);
    });

    cosmas.setMap(map);

    var clinicwindow = new google.maps.InfoWindow({
        content: 'TASUED Health Centre (Clinic)'
    });

    var clinic = new google.maps.Marker({
        position: clinicP,
        map: map,
        title: "Health Centre!",
        icon: clinicon
    });

    google.maps.event.addListener(clinic, 'click', function () {
        clinicwindow.open(map, clinic);
    });

    clinic.setMap(map);

    //field
    var fieldP = new google.maps.LatLng(6.781800, 3.924914);

    var fieldString = 'Sports field';

    var fieldwindow = new google.maps.InfoWindow({
        content: 'TASUED Sports Complex'
    });

    var field = new google.maps.Marker({
        position: fieldP,
        map: map,
        title: "Field!",
        icon: fieldon
    });

    google.maps.event.addListener(field, 'click', function () {
        fieldwindow.open(map, field);
    });

    field.setMap(map);
	
	switch(x) {
            case 'ogd':
                ogdwindow.open(map,ogd);
                break;
            case 'library':
                librarywindow.open(map,library);
                break;
            case 'pps':
                ppswindow.open(map,pps);
                break;
            case 'ict':
                ictwindow.open(map,ict);
                break;
            case 'sbk':
                sbkwindow.open(map,sbk);
                break;
            case 'cepep':
                cepepwindow.open(map,cepep);
                break;
            case 'auditorium':
                auditoriumwindow.open(map,auditorium);
                break;
            case 'elearning':
                elearningwindow.open(map,elearning);
                break;
            case 'vcbuilding':
                vcbuildingwindow.open(map,vcbuilding);
                break;
            case 'adoffice':
                adofficewindow.open(map,adoffice);
                break;
            case 'lt':
                ltwindow.open(map,lt);
                break;
            case 'etfcoaevot':
                etfcoaevotwindow.open(map,etfcoaevot);
                break;
            case 'kaaf':
                kaafwindow.open(map,kaaf);
                break;
            case 'coaevot':
                coaevotwindow.open(map,coaevot);
                break;
            case 'cosmas':
                cosmaswindow.open(map,cosmas);
                break;
            case 'clinic':
                clinicwindow.open(map,clinic);
                break;
            case 'field':
                fieldwindow.open(map,field);
                break;
        }
}
google.maps.event.addDomListener(window, 'load', initialize);

//handle location error
function handleLocationError(browserHasGeolocation, infoWindow, pos) {
    infoWindow.setPosition(pos);
    infoWindow.setContent(browserHasGeolocation ?
                          'Error: The Geolocation service failed.' :
                          'Error: Your device doesn\'t support geolocation.');
}